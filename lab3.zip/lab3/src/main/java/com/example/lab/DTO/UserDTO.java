package com.example.lab.DTO;

import lombok.Data;

@Data

public class UserDTO {
    private String username;
}